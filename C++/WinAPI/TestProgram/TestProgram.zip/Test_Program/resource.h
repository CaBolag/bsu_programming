//{{NO_DEPENDENCIES}}
// ���������� ����, ��������� � Microsoft Visual C++.
// ������������ Test_Program.rc
//
#define IDD_DIALOG1                     101
#define IDC_EDIT1                       1001
#define IDC_BUTTON1                     1002
#define IDC_BUTTON_OPEN                 1002
#define IDC_BUTTON_PREV                 1003
#define IDC_BUTTON_NEXT                 1004
#define IDC_BUTTON_FINISH               1005
#define IDC_RADIO1                      1006
#define IDC_RADIO2                      1007
#define IDC_RADIO3                      1008
#define IDC_CHECK1                      1009
#define IDC_CHECK2                      1010
#define IDC_CHECK3                      1011
#define IDC_CHECK4                      1012
#define IDC_CHECK5                      1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
