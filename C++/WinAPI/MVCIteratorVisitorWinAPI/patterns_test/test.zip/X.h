#pragma once
#pragma once
#include <iostream>
#include <memory>
#include <algorithm>
#include <sstream>
#include <iterator>
#include<vector>
#include<fstream>
#include "CardinalityVisitor.h"
#include"SaveVisitor.h"
#include "XIterator.h"


class X
{
public:
	X(): size_{ 100 }, data_{ new bool[100] }{};
	~X();


	X(const X&) = default;
	X(X&&) = default;
	X& operator=(const X&) = default;
	X& operator=(X&&) = default;


	void Add(size_t element);
	size_t Cardinality(CardinalityVisitor& visitor) const;
	void Save(SaveVisitor& visitor, std::string filename) const;
	bool GetAt(int index) const;
	std::string GetStringOfElements()const;
	std::string GetStringOfData()const;

	void Swap(X& x);
	size_t Size() const;
	

	void Accept(Visitor& visitor) const;

private:
	size_t size_;;
	bool* data_;

	//X(const X&) = default;
	//X(X&&) = default;
	//X& operator=(const X&) = default;
	//X& operator=(X&&) = default;
};

std::ostream& operator <<(std::ostream& out, const X& x);
