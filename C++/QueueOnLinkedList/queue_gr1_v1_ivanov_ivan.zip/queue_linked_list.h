//
// Created by Victor on 04.12.2020.
//

#ifndef QUEUE_LINKED_LIST_H_
#define QUEUE_LINKED_LIST_H_

#include<iostream>
#include <vector>
template<class T>
class QueueLinkedList {
 public:
  struct Node {
    T value;
   private:
    Node *previous;
    Node *next;
    Node() = default;
    explicit Node(const T &_value, Node *_previous = nullptr, Node *_next = nullptr) :
        value(_value), previous(_previous), next(_next) {}
   public:
    ~Node() = default;
    friend struct QueueLinkedList;
  };

  QueueLinkedList() : size(0), head(nullptr), tail(nullptr) {}
  // ~QueueLinkedList();
  QueueLinkedList(const std::initializer_list<T> &list);
  QueueLinkedList(const QueueLinkedList<T> &);
  QueueLinkedList(QueueLinkedList<T> &&);
  int Size() { return size };
  bool IsEmpty() { return size == 0 };
  std::vector<T> ToVector() {}
  Node* Head() { return head };
  Node *Tail() { return tail};
  const Node *Head() const { return head };
  const Node *Tail() const { return tail };
  void Push(const T &value);
  void Push(const T &&value) {}
  T Pop();
  int Find(const T &value) {}
  std::vector<int> FindAll(const T &value) {}
  Node *operator[](size_t);
  const Node *operator[](size_t) const;

  QueueLinkedList<T> &operator=(const QueueLinkedList<T> &);
  QueueLinkedList<T> &operator=(QueueLinkedList<T> &&);

  bool operator==(const QueueLinkedList &i) const {}
  bool operator!=(const QueueLinkedList &i) const {}

 private:
  size_t size;
  Node *head;
  Node *tail;
};

/*template <class T>
QueueLinkedList<T>::~QueueLinkedList()
{
    while (size > 0)
    {
        Pop();
    }
};*/

template<class T>
void QueueLinkedList<T>::Push(const T &value) {
  Node *newNode = new Node(value, tail);
  if (size == 0) {
    head = newNode;
  } else {
    tail->next = newNode;
  }
  tail = newNode;
  ++size;
}

template<class T>
T QueueLinkedList<T>::Pop() {
  if (size == 0) {
    std::cout << "List is empty" << std::endl;
    return T();
  }

  Node *temp = head;
  T key = temp->value;
  head = head->next;
  delete temp;
  if (size == 1) {
    tail = nullptr;
  }
  size--;
  return key;
}

template<typename T>
QueueLinkedList<T>::QueueLinkedList(const std::initializer_list<T> &list) : 
    QueueLinkedList() {
  for (T value : list) {
    Push(value);
  }
}

template<class T>
typename QueueLinkedList<T>::
Node *QueueLinkedList<T>::operator[](size_t index) {
  if (index >= size) {
    std::cout << "Wrong index.\n";
    exit(0);
  }
  Node *cur = head;
  for (size_t i = 0; i < index; i++, cur = cur->next);

  return cur;
}

template<class T>
QueueLinkedList<T>::QueueLinkedList(const QueueLinkedList<T> &queue) {
  size = 0;
  head = tail = nullptr;
  for (Node *cur = queue.head; cur; cur = cur->next) {
    Push(cur->value);
  }
}

template<class T>
QueueLinkedList<T>::QueueLinkedList(QueueLinkedList<T> &&queue) {
  size = queue.size;
  head = queue.head;
  tail = queue.tail;
  queue.size = 0;
  queue.head = nullptr;
  queue.tail = nullptr;
}


#endif // QUEUE_LINKED_LIST_H_
