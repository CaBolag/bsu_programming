

#ifndef VAR_8__HEADERS_H_
#define VAR_8__HEADERS_H_
#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<iterator>
#include<fstream>
#include <set>
#include <sstream>

#include "Master.h"
#include "AutoRepairShop.h"
#include "RepairedAuto.h"
#include "CompletedWork.h"
#include "CityService.h"
#endif //VAR_8__HEADERS_H_
